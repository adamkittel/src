json=$1
thresh=$2
iterations=$3
pausebetween=1

if [[ ( "$json" = "" ) || ( "$thresh" = "" ) || ( "$iterations" = "" ) ]]; then
 echo "Usage is './all_volumes_utilization <json file> <threshold> <# of iterations>'"
 echo "For example:"
 echo "User> ./all_volumes_utilization example-conf.json 85 5"
 echo "Collected Sample 1"
 echo "Collected Sample 2"
 echo "Collected Sample 3"
 echo "Collected Sample 4"
 echo "Collected Sample 5" 
 echo "File Volumesover85% Created"
 exit
fi

mvip=`grep mvip $json | grep -Eo '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'`
password=`grep password $json`
password=${password:14}
password=${password%%??}
login=`grep login $json`
login=${login:11}
login=${login%%??}

filename="Volumesover$thresh%"

wget -q --no-check-certificate --http-user=$login --http-password=$password "https://$mvip/json-rpc/1.0/?method=GetCompleteStats"
grep activeSessions index* | grep -oE "[[:digit:]]{1,}" >> /solidfire/a
volumes=`cat /solidfire/a | sed -n 1p | bc`
rm index*
rm /solidfire/a

sum[0]=0
for (( j = 1; j <= $volumes; j++ ))
do
sum[$j]=0
done

for ((  i = 1 ;  i <= $iterations;  i++  ))
do
for (( volume = 1 ; volume <= $volumes; volume++ ))
do
wget -q --no-check-certificate --http-user=$login --http-password=$password "https://$mvip/json-rpc/1.0/?method=GetVolumeStats&volumeID=$volume" 
grep volumeUtilization index* |grep -oE "[[:digit:]]{1,}" >> u.txt
n1=$(cat u.txt | sed -n 1p)
n2=$(cat u.txt | sed -n 2p)
n3=$n1.$n2
sum[$volume]=`echo "$n3 + ${sum[$volume]}" | bc`
rm index*
rm u.txt
done
echo "Collected Sample $i"
sleep $pausebetween
done

for (( volume = 1 ; volume <= $volumes; volume++ ))
do
ave[$volume]=`echo "${sum[$volume]} / $iterations" | bc -l|xargs printf "%1.3f"`
done

date >> $filename.txt

for (( volume = 1 ; volume <= $volumes; volume++ ))
do
 ave1=`echo "${ave[$volume]} * 100" | bc -l | xargs printf "%5.0f"`
  if [ $ave1 -ge $thresh ]; then
   echo "Volume $volume utilization is:" >> $filename.txt
   echo -n $ave1 >> $filename.txt
   echo "%" >> $filename.txt
  fi	
done
echo "File $filename Created"
