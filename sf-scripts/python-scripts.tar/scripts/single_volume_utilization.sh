json=$1
volume=$2
iterations=$3

if [[ ( "$volume" = "" ) || ( "$iterations" = "" ) || ( "$json" = "" ) ]]; then
 echo "Usage is './single_volume_utilization <json file> <volume #> <# of samples>'"
 echo "For example:"
 echo "User> ./single_volume_utilization example-conf.json 32 5"
 echo "Collected Sample 1"
 echo "Collected Sample 2"
 echo "Collected Sample 3"
 echo "Collected Sample 4"
 echo "Collected Sample 5" 
 echo "Current Utilization is: 23.7%"
 exit
fi

mvip=`grep mvip $json | grep -Eo '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'`
password=`grep password $json`
password=${password:14}
password=${password%%??}
login=`grep login $json`
login=${login:11}
login=${login%%??}
sum=0

for ((  i = 1 ;  i <= $iterations;  i++  ))
do
wget -q --no-check-certificate --http-user=$login --http-password=$password "https://$mvip/json-rpc/1.0/?method=GetVolumeStats&volumeID=$volume" 
grep volumeUtilization index* |grep -oE "[[:digit:]]{1,}" >> u.txt
n1=$(cat u.txt | sed -n 1p)
n2=$(cat u.txt | sed -n 2p)
n3=$n1.$n2
sum=`echo "$n3 + $sum" | bc`
rm index*
rm u.txt
echo "Collected Sample $i"
sleep 1
done

ave=`echo "$sum / $iterations" | bc -l|xargs printf "%1.3f"`

avepct=`echo "$ave * 100" | bc -l|xargs printf "%3.1f"`
echo "Current Utilization is: $avepct%"

