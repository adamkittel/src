json=$1

if [[ ( "$json" = "" ) ]]; then
echo "Usage is './current_performance_provisioning.sh <json file>'"
echo "For example:"
echo "User> ./current_performance_provisioning.sh example-conf.json"
exit
fi

mvip=`grep mvip $json | grep -Eo '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'`
password=`grep password $json`
password=${password:14}
password=${password%%??}
login=`grep login $json`
login=${login:11}
login=${login%%??}

wget -q --no-check-certificate --http-user=$login --http-password=$password "https://$mvip/json-rpc/1.0/?method=ListActiveVolumes" 
wget -q --no-check-certificate --http-user=$login --http-password=$password "https://$mvip/json-rpc/1.0/?method=GetCompleteStats"
grep maxIOPS *ListActiveVolumes |grep -oE "[[:digit:]]{1,}" >> max.txt
grep minIOPS *ListActiveVolumes |grep -oE "[[:digit:]]{1,}" >> min.txt
grep burstIOPS *ListActiveVolumes |grep -oE "[[:digit:]]{1,}" >> burst.txt
grep nodeCount *GetCompleteStats |grep -oE "[[:digit:]]{1,}" >> nodes.txt
min=`awk '{ sum += $1 } END { print sum }' min.txt`
max=`awk '{ sum += $1 } END { print sum }' max.txt`
burst=`awk '{ sum += $1 } END { print sum }' burst.txt`
ciops=`awk '{ sum += $1 } END { print sum * 50000 }' nodes.txt`
minpct=$(echo "scale=2; $min / $ciops * 100" | bc)
maxpct=$(echo "scale=2; $max / $ciops * 100" | bc)
burstpct=$(echo "scale=2; $burst / $ciops * 100" | bc)

echo "Provisioned MIN IOPS:"
echo "$min ($minpct%)"

echo "Provisioned MAX IOPS:"
echo "$max ($maxpct%)"

echo "Provisioned BURST IOPS:"
echo "$burst ($burstpct%)"

echo "Cluster IOPS:"
echo $ciops

rm min.txt
rm max.txt
rm burst.txt
rm nodes.txt
rm index*

