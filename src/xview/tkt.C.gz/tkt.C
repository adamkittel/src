//TROUBLE TICKET THING

#include <xview/generic.h>
#include <xview/xview.h>
#include <xview/frame.h>
#include <xview/panel.h>
#include <xview/openmenu.h>
#include <iostream.h>

//////////////////////////////////////////////////
//MAKE A GLOBAL FRAME
//////////////////////////////////////////////////
Frame frame;

//////////////////////////////////////////////////
//FUNCTION PROTOTYPES
//////////////////////////////////////////////////
int menuHandler(Menu item, Menu_item selection);
int selected(Panel_item, Event *ev);
int texthandler(Panel_item text);
void quit();

//////////////////////////////////////////////////
//MAIN
//////////////////////////////////////////////////
int main(int argc, char *argv[])
{
   
  ////////////////////////////////////////
  //DEFINE PANEL AND MENU STRUCTURES
  ////////////////////////////////////////
  Panel panel;
  Panel ticketpnl;
  Panel dateNtimepnl;
  Panel user_namepnl;
  Panel statuspnl;
  Panel toolpnl;
  Panel summarypnl;
  Panel machinepnl;
  Panel historypnl;
  Panel downtmpnl;
  Panel buttonpnl;
  Panel quitpnl;
  Menu ownermnu;
  Menu statusmnu;
  Menu toolmnu;

  /////////////////////////////////////////
  //INITIALIZE THE XV INIT ENGINE
  ////////////////////////////////////////
  xv_init(XV_INIT_ARGC_PTR_ARGV, &argc, argv, 0);
  
  /////////////////////////////////////////
  //MAKE THE MAIN FRAME
  ////////////////////////////////////////
  frame = (Frame)xv_create(0, FRAME, FRAME_LABEL, "Trouble ticket",
			   FRAME_SHOW_FOOTER, TRUE,
			   FRAME_LEFT_FOOTER, "Adam's Trouble Ticketer",
			   FRAME_RIGHT_FOOTER, argv[0],
			   XV_WIDTH, 500,
			   XV_HEIGHT, 600, 
			   NULL);
  
  /////////////////////////////////////////
  //MAKE THE MAIN PANEL FOR CONTROLS
  ////////////////////////////////////////
  panel = (Panel)xv_create(frame, PANEL, NULL);

  ////////////////////////////////////////
  ////////////////////////////////////////
  //ADD CONTROLS TO THE PANEL
  ////////////////////////////////////////
  ////////////////////////////////////////
  
  ////////////////////////////////////////
  //DATE AND TIME ENTRY FIELDS
  //LOAD CURRENT DATE AND TIME OR LOAD
  //FROM PREVIOUS TICKET FILE
  /////////////////////////////////////////
  dateNtimepnl = (Panel)xv_create(panel, PANEL_TEXT,
				  PANEL_LABEL_STRING, "Date: ",
				  PANEL_VALUE_DISPLAY_LENGTH, 20,	   
				  PANEL_VALUE, "Feb-4-1997",
				  NULL);
  
  dateNtimepnl = (Panel) xv_create(panel, PANEL_TEXT,
				   PANEL_LABEL_STRING, "Time: ",
				   PANEL_VALUE_DISPLAY_LENGTH, 20,	
				   PANEL_VALUE, "00:42:58",
				   NULL);
  
  ////////////////////////////////////////
  //USER MENU BUTTON
  //FIRST MAKE THE MENU
  //THEN MAKE THE PANEL AND ADD IT TO THE MAIN PANEL
  ////////////////////////////////////////
  ownermnu = (Menu) xv_create(0, MENU,
			      MENU_STRINGS, "akittel","rcrapo","rshannon",
			      "mburris","jblakely","agrimes","gtokarsk","oduong",
			      "tbillinger","jgardner","mklutke","cmiller", 
			      "dwhittaker","dpocia","dgoedeck","thawkins", 
			      "jmeans","sgreen","frontline", NULL,
			      MENU_NOTIFY_PROC, menuHandler,
			      NULL);
  
  user_namepnl = (Panel)xv_create(panel, PANEL_BUTTON,
			    PANEL_LABEL_STRING, "User Name",
			    PANEL_ITEM_MENU, ownermnu,
			    PANEL_NOTIFY_PROC, selected,
			    NULL);

  ////////////////////////////////////////
  //STATUS MENU BUTTON
  //SAME PROCEEDURE
  ////////////////////////////////////////
  statusmnu = (Menu)xv_create(0, MENU,
			      MENU_STRINGS, "Open","Closed", NULL,
			      MENU_NOTIFY_PROC, menuHandler,
			      NULL);
  
  statuspnl =  (Panel)xv_create(panel, PANEL_BUTTON,
			 PANEL_LABEL_STRING, "Status",
			 PANEL_ITEM_MENU, statusmnu,
			 PANEL_NOTIFY_PROC, selected,
			 NULL);
  
  ////////////////////////////////////////
  //TOOL MENU BUTTON
  //SAME PROCEEDURE
  ////////////////////////////////////////
  toolmnu = (Menu)xv_create(0, MENU,
			    MENU_STRINGS, "Phone call/Pager","RSM","SNM","Tivoli",
			    "cppv-monitor","frontline","Web tool","Other",NULL,
			    MENU_NOTIFY_PROC, menuHandler,
			    NULL);

  toolpnl = (Panel) xv_create(panel, PANEL_BUTTON,
			      PANEL_LABEL_STRING, "Monitoring Tool",
			      PANEL_ITEM_MENU, toolmnu,
			      PANEL_NOTIFY_PROC, selected,
			      NULL);
  
  ////////////////////////////////////////
  //MAKE PROBLEM SUMMARY TEXT BOX
  ////////////////////////////////////////
  summarypnl = (Panel)xv_create(panel, PANEL_MULTILINE_TEXT,
				PANEL_LAYOUT,PANEL_VERTICAL,
				PANEL_LABEL_STRING,"Problem Summary",
				PANEL_DISPLAY_ROWS, 3,
				PANEL_VALUE_DISPLAY_LENGTH,50,
				PANEL_NOTIFY_PROC, texthandler,
				NULL);
				
  ////////////////////////////////////////
  //MAKE EFFECTED MAHINES TEXT LINE
  ////////////////////////////////////////
  machinepnl = (Panel)xv_create(panel, PANEL_TEXT,
				PANEL_LAYOUT,PANEL_VERTICAL,
				PANEL_LABEL_STRING,"Effected Machines",
				PANEL_VALUE_DISPLAY_LENGTH, 50,
				PANEL_NOTIFY_PROC, texthandler,
				NULL);

  ////////////////////////////////////////
  //MAKE UPDATE HISTORY BOX
  ////////////////////////////////////////
  historypnl = (Panel)xv_create(panel,  PANEL_MULTILINE_TEXT,
				PANEL_LAYOUT,PANEL_VERTICAL,
				PANEL_LABEL_STRING,"Udate History",
				PANEL_DISPLAY_ROWS, 15,
				PANEL_VALUE_DISPLAY_LENGTH,50,
				PANEL_NOTIFY_PROC, texthandler,
				NULL);

  ////////////////////////////////////////
  //CUSTOMER DOWNTIME TEXT LINE
  ////////////////////////////////////////
   downtmpnl = (Panel)xv_create(panel, PANEL_TEXT,
				PANEL_LAYOUT,PANEL_VERTICAL,
				PANEL_LABEL_STRING,"Customer Downtime",
				PANEL_VALUE_DISPLAY_LENGTH, 50,
				PANEL_NOTIFY_PROC, texthandler,
				NULL);

   ////////////////////////////////////////
   //MAKE SUBMIT AND EPAGE BUTTONS
   ////////////////////////////////////////
   buttonpnl = (Panel)xv_create(panel, PANEL_BUTTON,
				PANEL_LABEL_STRING,"Submit",
				 PANEL_NOTIFY_PROC, quit,
				XV_X,5,
				XV_Y,500,
				NULL);

   buttonpnl = (Panel)xv_create(panel, PANEL_BUTTON,
				PANEL_LABEL_STRING,"Epage",
				PANEL_NOTIFY_PROC, quit,
				XV_X,55,
				XV_Y,500,
				NULL);

  ////////////////////////////////////////
  //MAKE A QUIT BUTTON ON A PANEL
  //ADD IT TO THE MAIN PANEL
  ////////////////////////////////////////
  quitpnl = (Panel) xv_create(panel, PANEL_BUTTON ,
			      PANEL_LABEL_STRING, "QUIT",
			      PANEL_NOTIFY_PROC, quit,
			      NULL);
  
  /////////////////////////////////////////
  //MAIN LOOP MAKES IT GO
  ////////////////////////////////////////
  xv_main_loop(frame);
  return 0;
}


void quit()
{
  xv_destroy_safe(frame);
}

int menuHandler(Menu item, Menu_item thing)
{
  printf("menuHandler..%s\n",xv_get(thing, MENU_STRING));
  return 0;
}

int selected(Panel_item item, Event *ev)
{
  printf("selected..%s\n",xv_get(item, PANEL_LABEL_STRING));
    return 0;
}

int texthandler(Panel_item text)
{
   printf("%s\n",xv_get(text ,PANEL_VALUE));
   return 0;
}
