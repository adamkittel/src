import java.awt.*;
import java.applet.*;

public class hello extends Applet
{
	public void paint(Graphics g)
	{
		Font font = new Font("TimesRoman",Font.BOLD, 24);
		g.setFont(font);
		g.drawString("hello Damnit",5,5);
	}
}