print <<__FAILHTML__;
<HTML><HEAD>
<TITLE>Woopsy</TITLE>
</HEAD>
<BODY BGCOLOR = "FFFFFF" TEXT = "000000">

<BLOCKQUOTE>
Sorry, it appears that you are unauthorized for this web page.
Contact your web server administration 
</BLOCKQUOTE>

</BODY></HTML>


__FAILHTML__

1;

